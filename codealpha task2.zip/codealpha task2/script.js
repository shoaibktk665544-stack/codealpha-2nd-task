let display = document.getElementById('display');

/* Add value to display */
function appendValue(val){
  display.value += val;
}

/* Clear display */
function clearDisplay(){
  display.value = '';
}

/* Calculate expression */
function calculate(){
  let expression = display.value.replace(/×/g,'*').replace(/÷/g,'/');
  try{
    display.value = eval(expression);
  }catch(e){
    display.value = 'Error';
  }
}

/* Keyboard support */
document.addEventListener('keydown', function(e){
  if((e.key>='0' && e.key<='9') || e.key=='+' || e.key=='-' || e.key=='*' || e.key=='/'){
    appendValue(e.key=='*'?'×': e.key=='/'?'÷': e.key);
  }
  if(e.key=='Enter'){ calculate(); }
  if(e.key=='Backspace'){ display.value = display.value.slice(0,-1); }
  if(e.key=='c' || e.key=='C'){ clearDisplay(); }
});
